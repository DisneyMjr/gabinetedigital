<?php
// admin_assinatura.php - PAINEL DE PAGAMENTO DO CLIENTE
session_start();
require 'conexao.php';
require 'efi_config.php';

$tenant_id = $_SESSION['tenant_id'] ?? 0;
$user_nome = $_SESSION['user_nome'] ?? '';

if (!$tenant_id) {
    die("Acesso restrito.");
}

// Busca os dados da empresa
$stmt = $pdo->prepare("SELECT * FROM tenants WHERE id = ?");
$stmt->execute([$tenant_id]);
$empresa = $stmt->fetch();

$erro = '';
$link_pagamento = '';

// --- SE CLICAR EM "GERAR PAGAMENTO" ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['gerar_cobranca'])) {
    
    $token = getEfiToken();
    
    if ($token) {
        $url_base = EFI_SANDBOX ? 'https://sandbox.gerencianet.com.br' : 'https://api.gerencianet.com.br';
        
        // 1. Criar a Transação (Charge)
        $payload_charge = [
            'items' => [
                [
                    'name' => 'Assinatura Mensal - Ouvvi SaaS',
                    'value' => 9700, // R$ 97,00 (O valor é em centavos)
                    'amount' => 1
                ]
            ]
        ];
        
        $ch1 = curl_init($url_base . '/v1/charge');
        curl_setopt_array($ch1, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $token, 'Content-Type: application/json'],
            CURLOPT_POSTFIELDS => json_encode($payload_charge)
        ]);
        
        $res1 = json_decode(curl_exec($ch1), true);
        curl_close($ch1);
        
        if (isset($res1['data']['charge_id'])) {
            $charge_id = $res1['data']['charge_id'];
            
            // 2. Gerar o Link de Pagamento (Checkout)
            $payload_link = [
                'billet_discount' => 0,
                'card_discount' => 0,
                'message' => 'Pagamento da assinatura do sistema Ouvvi',
                'expire_at' => date('Y-m-d', strtotime('+3 days')), // Link expira em 3 dias
                'payment_method' => 'all' // Permite PIX, Boleto e Cartão
            ];
            
            $ch2 = curl_init($url_base . '/v1/charge/' . $charge_id . '/link');
            curl_setopt_array($ch2, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $token, 'Content-Type: application/json'],
                CURLOPT_POSTFIELDS => json_encode($payload_link)
            ]);
            
            $res2 = json_decode(curl_exec($ch2), true);
            curl_close($ch2);
            
            if (isset($res2['data']['payment_url'])) {
                $link_pagamento = $res2['data']['payment_url'];
                
                // Salva o Charge ID no banco para controle futuro
                $stmtUpd = $pdo->prepare("UPDATE tenants SET efi_charge_id = ? WHERE id = ?");
                $stmtUpd->execute([$charge_id, $tenant_id]);
                
                // Redireciona o cliente para a tela de pagamento da Efí
                header("Location: " . $link_pagamento);
                exit;
            } else {
                $erro = "Erro ao gerar link de pagamento.";
            }
        } else {
            $erro = "Erro ao criar transação na Efí.";
        }
    } else {
        $erro = "Falha de autenticação com o banco (Efí). Verifique suas credenciais.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Assinatura | Ouvvi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body { background-color: #f4f6f9; font-family: 'Segoe UI', sans-serif; }
        .wrapper { display: flex; min-height: 100vh; }
        #sidebar { min-width: 250px; background: #0f172a; color: #fff; }
        #sidebar ul li a { padding: 12px 20px; display: block; color: rgba(255,255,255,0.7); text-decoration: none; }
        #sidebar ul li a.active { color: #fff; background: rgba(255,255,255,0.1); border-left: 4px solid #0d6efd; }
    </style>
</head>
<body>
    <div class="wrapper">
        <nav id="sidebar">
            <div class="p-4 text-center"><h4 class="fw-bold text-primary">Ouvvi</h4></div>
            <ul class="list-unstyled">
                <li><a href="admin.php"><i class="bi bi-arrow-left"></i> Voltar ao Painel</a></li>
                <li class="px-4 mt-3 small text-muted text-uppercase">Financeiro</li>
                <li><a href="admin_assinatura.php" class="active"><i class="bi bi-credit-card-fill"></i> Minha Assinatura</a></li>
            </ul>
        </nav>

        <div id="content" class="w-100 p-5">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <h3 class="fw-bold mb-4">Minha Assinatura</h3>
                    
                    <?php if($erro): ?>
                        <div class="alert alert-danger fw-bold"><i class="bi bi-exclamation-triangle"></i> <?php echo $erro; ?></div>
                    <?php endif; ?>

                    <div class="card border-0 shadow-sm p-4 text-center" style="border-radius: 20px;">
                        <h5 class="text-muted text-uppercase fw-bold mb-3">Plano Profissional</h5>
                        <h1 class="display-3 fw-bold text-primary mb-4">R$ 97<span class="fs-4 text-muted">,00/mês</span></h1>
                        
                        <ul class="list-unstyled text-start mb-4 mx-auto" style="max-width: 300px;">
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Relatos Ilimitados</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Análise de IA em tempo real</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Criptografia de ponta a ponta</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill text-success me-2"></i> Suporte Especializado</li>
                        </ul>

                        <form method="POST">
                            <input type="hidden" name="gerar_cobranca" value="1">
                            <button type="submit" class="btn btn-primary btn-lg w-100 fw-bold rounded-pill shadow">
                                <i class="bi bi-lock-fill"></i> Pagar Agora (PIX/Cartão)
                            </button>
                        </form>
                        <p class="small text-muted mt-3"><i class="bi bi-shield-check"></i> Pagamento processado com segurança pela Efí.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
