<?php
// efi_config.php - CREDENCIAIS DO GATEWAY DE PAGAMENTO (EFÍ)

// Substitua pelas suas credenciais reais da Efí (Ambiente de Produção ou Homologação)
define('EFI_CLIENT_ID', 'Client_Id_sua_chave_aqui');
define('EFI_CLIENT_SECRET', 'Client_Secret_sua_chave_aqui');

// Se for ambiente de testes (Homologação) use true, se for Produção use false
define('EFI_SANDBOX', true); 

function getEfiToken() {
    $url = EFI_SANDBOX ? 'https://sandbox.gerencianet.com.br/v1/authorize' : 'https://api.gerencianet.com.br/v1/authorize';
    
    $credentials = base64_encode(EFI_CLIENT_ID . ':' . EFI_CLIENT_SECRET);
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Basic ' . $credentials,
        'Content-Type: application/json'
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['grant_type' => 'client_credentials']));
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    $json = json_decode($response, true);
    return $json['access_token'] ?? null;
}
?>
