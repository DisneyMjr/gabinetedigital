<?php
// admin_config.php - CONFIGURAÇÕES DO PORTAL E SLA (Ouvvi)
session_start();
require 'conexao.php';
require 'verificar_assinatura.php';

$tenant_id = $_SESSION['tenant_id'];
$user_nome = $_SESSION['user_nome'];
$mensagem = '';

// --- SALVAR CONFIGURAÇÕES ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $prazo_padrao = (int)$_POST['prazo_padrao'];
    $prazo_recurso = (int)$_POST['prazo_recurso'];
    $prazo_prorrogacao = (int)$_POST['prazo_prorrogacao'];
    
    // Checkboxes (se não vier no POST, é 0)
    $dias_uteis = isset($_POST['dias_uteis']) ? 1 : 0;
    $exigir_cpf = isset($_POST['exigir_cpf']) ? 1 : 0;
    $permitir_anonimo = isset($_POST['permitir_anonimo']) ? 1 : 0;
    
    $texto_apresentacao = trim($_POST['texto_apresentacao']);

    $sqlUpd = "UPDATE tenants SET 
               prazo_padrao = ?, prazo_recurso = ?, prazo_prorrogacao = ?, 
               dias_uteis = ?, exigir_cpf = ?, permitir_anonimo = ?, texto_apresentacao = ? 
               WHERE id = ?";
    
    $stmtUpd = $pdo->prepare($sqlUpd);
    if($stmtUpd->execute([$prazo_padrao, $prazo_recurso, $prazo_prorrogacao, $dias_uteis, $exigir_cpf, $permitir_anonimo, $texto_apresentacao, $tenant_id])) {
        $mensagem = "<div class='alert alert-success fw-bold'><i class='bi bi-check-circle'></i> Configurações salvas com sucesso!</div>";
    } else {
        $mensagem = "<div class='alert alert-danger fw-bold'><i class='bi bi-exclamation-triangle'></i> Erro ao salvar.</div>";
    }
}

// --- BUSCAR DADOS ATUAIS ---
$stmt = $pdo->prepare("SELECT nome_empresa, prazo_padrao, prazo_recurso, prazo_prorrogacao, dias_uteis, exigir_cpf, permitir_anonimo, texto_apresentacao FROM tenants WHERE id = ?");
$stmt->execute([$tenant_id]);
$config = $stmt->fetch();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Configurações | Ouvvi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body { background-color: #f4f6f9; font-family: 'Segoe UI', sans-serif; }
        .bg-gradient-dark { background: linear-gradient(135deg, #212529 0%, #343a40 100%); }
        .card-custom { border: none; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        .form-switch .form-check-input { width: 3em; height: 1.5em; cursor: pointer; }
        .form-check-label { margin-top: 0.3em; margin-left: 0.5em; cursor: pointer; }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-gradient-dark px-4 shadow-sm">
        <a class="navbar-brand fw-bold" href="admin.php"><i class="bi bi-arrow-left me-2"></i> Voltar ao Painel</a>
        <div class="ms-auto text-white fw-semibold">
            <i class="bi bi-gear-fill"></i> Configurações: <?php echo htmlspecialchars($config['nome_empresa']); ?>
        </div>
    </nav>

    <div class="container mt-4 pb-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                
                <?php echo $mensagem; ?>

                <form method="POST" class="card card-custom bg-white p-4 p-md-5">
                    
                    <h5 class="text-primary fw-bold mb-4"><i class="bi bi-hourglass-split"></i> Prazos e SLA (Acordo de Nível de Serviço)</h5>
                    
                    <div class="row g-3 mb-4">
                        <div class="col-md-4">
                            <label class="form-label small fw-semibold">Prazo Padrão (Dias)</label>
                            <input type="number" name="prazo_padrao" class="form-control" value="<?php echo $config['prazo_padrao']; ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small fw-semibold">Prazo para Recurso</label>
                            <input type="number" name="prazo_recurso" class="form-control" value="<?php echo $config['prazo_recurso']; ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small fw-semibold">Dias de Prorrogação</label>
                            <input type="number" name="prazo_prorrogacao" class="form-control" value="<?php echo $config['prazo_prorrogacao']; ?>" required>
                        </div>
                    </div>

                    <div class="form-check form-switch mb-4 pb-3 border-bottom">
                        <input class="form-check-input" type="checkbox" role="switch" id="diasUteis" name="dias_uteis" <?php echo $config['dias_uteis'] ? 'checked' : ''; ?>>
                        <label class="form-check-label text-dark fw-semibold" for="diasUteis">
                            Contagem em Dias Úteis (se desmarcado, conta dias corridos)
                        </label>
                    </div>

                    <h5 class="text-primary fw-bold mb-4"><i class="bi bi-window-desktop"></i> Portal Público do Cidadão</h5>

                    <div class="form-check form-switch mb-3">
                        <input class="form-check-input" type="checkbox" role="switch" id="permitirAnonimo" name="permitir_anonimo" <?php echo $config['permitir_anonimo'] ? 'checked' : ''; ?>>
                        <label class="form-check-label text-dark fw-semibold" for="permitirAnonimo">
                            Permitir denúncias 100% anônimas
                        </label>
                    </div>

                    <div class="form-check form-switch mb-4 pb-3 border-bottom">
                        <input class="form-check-input" type="checkbox" role="switch" id="exigirCpf" name="exigir_cpf" <?php echo $config['exigir_cpf'] ? 'checked' : ''; ?>>
                        <label class="form-check-label text-dark fw-semibold" for="exigirCpf">
                            Exigir CPF/CNPJ para manifestantes identificados
                        </label>
                    </div>

                    <div class="mb-4">
                        <label class="form-label small fw-semibold">Texto de Apresentação (Página Inicial da Ouvidoria)</label>
                        <textarea name="texto_apresentacao" class="form-control" rows="5" placeholder="Ex: A Ouvidoria é o seu canal direto de comunicação..."><?php echo htmlspecialchars($config['texto_apresentacao'] ?? ''); ?></textarea>
                        <div class="form-text">Este texto aparecerá logo acima do formulário para o cidadão/colaborador.</div>
                    </div>

                    <div class="d-flex justify-content-end">
                        <a href="admin.php" class="btn btn-light me-2 fw-bold">Cancelar</a>
                        <button type="submit" class="btn btn-primary px-4 fw-bold"><i class="bi bi-save"></i> Salvar Configurações</button>
                    </div>

                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>