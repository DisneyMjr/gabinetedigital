<?php
// verificar_assinatura.php - AGORA COM BLOQUEIO IMEDIATO
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'conexao.php';

if (!isset($_SESSION['tenant_id'])) {
    header("Location: login.php");
    exit;
}

$tenant_id = $_SESSION['tenant_id'];

// Busca Data de Expiração E Status Ativo
$stmt = $pdo->prepare("SELECT data_expiracao, ativo FROM tenants WHERE id = ?");
$stmt->execute([$tenant_id]);
$empresa = $stmt->fetch();

if ($empresa) {
    // 1. CHECAGEM DE BLOQUEIO MANUAL (O botão que você apertou)
    if ($empresa['ativo'] == 0) {
        // Mata a sessão imediatamente
        session_destroy();
        
        // Exibe mensagem de bloqueio e para tudo
        die("
            <div style='font-family: sans-serif; text-align: center; padding-top: 50px;'>
                <h1 style='color: red;'>🚫 Acesso Suspenso</h1>
                <p>O acesso desta empresa foi bloqueado temporariamente pelo administrador.</p>
                <p>Entre em contato com o suporte para regularizar.</p>
                <a href='login.php'>Voltar ao Login</a>
            </div>
        ");
    }

    // 2. CHECAGEM DE DATA (Vencimento)
    $hoje = new DateTime();
    $validade = new DateTime($empresa['data_expiracao']);

    if ($hoje > $validade) {
        header("Location: pagamento.php");
        exit;
    }
} else {
    // Se a empresa não existe mais (foi deletada)
    session_destroy();
    header("Location: login.php");
    exit;
}
?>