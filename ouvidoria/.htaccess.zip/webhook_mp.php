<?php
// webhook_mp.php - RECEBE NOTIFICAÇÃO E LIBERA ACESSO
require 'conexao.php';

// Captura o Access Token
$stmt = $pdo->query("SELECT valor FROM system_config WHERE chave = 'mp_access_token'");
$access_token = $stmt->fetchColumn();

// Recebe a notificação
$input = file_get_contents("php://input");
$event = json_decode($input, true);

// Verifica se é um evento de pagamento
$payment_id = $event['data']['id'] ?? $_GET['id'] ?? null;

if ($payment_id && $access_token) {
    
    // CONSULTA O STATUS REAL NA API DO MERCADO PAGO (Segurança)
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://api.mercadopago.com/v1/payments/$payment_id");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ["Authorization: Bearer $access_token"]);
    $response = curl_exec($ch);
    curl_close($ch);

    $payment = json_decode($response, true);

    // Se estiver APROVADO
    if (isset($payment['status']) && $payment['status'] == 'approved') {
        
        $tenant_id = (int)$payment['external_reference']; // Recupera o ID da empresa
        $valor_pago = $payment['transaction_amount'];

        // 1. Registra no Histórico Financeiro
        // Verifica se já não foi registrado para evitar duplicidade
        $check = $pdo->prepare("SELECT id FROM payments WHERE obs LIKE ?");
        $check->execute(["%MP ID: $payment_id%"]);
        
        if ($check->rowCount() == 0) {
            $sqlPay = "INSERT INTO payments (tenant_id, valor, forma_pagamento, obs) VALUES (?, ?, 'Pix Automático', ?)";
            $stmtPay = $pdo->prepare($sqlPay);
            $stmtPay->execute([$tenant_id, $valor_pago, "MP ID: $payment_id"]);

            // 2. Renova a Validade (+30 dias) e Desbloqueia
            $sqlUpdate = "UPDATE tenants 
                          SET data_expiracao = DATE_ADD(GREATEST(data_expiracao, NOW()), INTERVAL 30 DAY), 
                              ativo = 1 
                          WHERE id = ?";
            $pdo->prepare($sqlUpdate)->execute([$tenant_id]);
        }
        
        http_response_code(200); // Avisa o MP que recebemos
        echo "OK";
    }
} else {
    http_response_code(400);
    echo "Bad Request";
}
?>