<?php
// Copie este arquivo para config.local.php e preencha com os dados do seu servidor.
return [
    'db_host' => 'localhost',
    'db_name' => 'SEU_BANCO',
    'db_user' => 'SEU_USUARIO',
    'db_pass' => 'SUA_SENHA',
    'app_key' => 'gere-uma-chave-longa-e-aleatoria-com-mais-de-32-caracteres',
    'openai_api_key' => '',
    'app_url' => 'https://seudominio.com.br',
    // Alternativamente, Mercado Pago pode ser configurado no Painel SaaS.
    'mp_access_token' => '',
    'mp_webhook_secret' => '',
];
