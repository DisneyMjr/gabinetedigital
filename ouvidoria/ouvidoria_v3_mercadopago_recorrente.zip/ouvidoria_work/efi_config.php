<?php
// Credenciais Efí via variáveis de ambiente. Nunca grave segredos diretamente neste arquivo.
define('EFI_CLIENT_ID', getenv('EFI_CLIENT_ID') ?: '');
define('EFI_CLIENT_SECRET', getenv('EFI_CLIENT_SECRET') ?: '');
define('EFI_SANDBOX', filter_var(getenv('EFI_SANDBOX') ?: 'true', FILTER_VALIDATE_BOOLEAN));

function getEfiToken() {
    if (!EFI_CLIENT_ID || !EFI_CLIENT_SECRET) return null;
    $url = EFI_SANDBOX ? 'https://sandbox.gerencianet.com.br/v1/authorize' : 'https://api.gerencianet.com.br/v1/authorize';
    $credentials = base64_encode(EFI_CLIENT_ID . ':' . EFI_CLIENT_SECRET);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_HTTPHEADER => [
            'Authorization: Basic ' . $credentials,
            'Content-Type: application/json'
        ],
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode(['grant_type' => 'client_credentials'])
    ]);
    $response = curl_exec($ch);
    if ($response === false) error_log('Efí token error: ' . curl_error($ch));
    curl_close($ch);
    $json = json_decode((string)$response, true);
    return $json['access_token'] ?? null;
}
