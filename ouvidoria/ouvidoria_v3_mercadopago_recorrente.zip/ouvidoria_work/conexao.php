<?php
// Configuração segura para cPanel/VPS.
// Prioridade: variáveis de ambiente > config.local.php.
$config = [];
$localConfig = __DIR__ . '/config.local.php';
if (is_file($localConfig)) {
    $loaded = require $localConfig;
    if (is_array($loaded)) $config = $loaded;
}

function cfg(string $env, string $localKey, ?string $default = null): ?string {
    global $config;
    $envValue = getenv($env);
    if ($envValue !== false && $envValue !== '') return $envValue;
    if (isset($config[$localKey]) && $config[$localKey] !== '') return (string)$config[$localKey];
    return $default;
}

$host = cfg('OUV_DB_HOST', 'db_host', 'localhost');
$db = cfg('OUV_DB_NAME', 'db_name');
$user = cfg('OUV_DB_USER', 'db_user');
$pass = cfg('OUV_DB_PASS', 'db_pass', '');
$charset = 'utf8mb4';
$appKey = cfg('OUV_APP_KEY', 'app_key');

if (!$db || !$user || !$appKey) {
    http_response_code(500);
    exit('Configuração incompleta. Copie config.local.example.php para config.local.php e informe banco, usuário e app_key.');
}

$dsn = "mysql:host={$host};dbname={$db};charset={$charset}";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    error_log('Falha de conexão com o banco: ' . $e->getMessage());
    http_response_code(500);
    exit('Não foi possível conectar ao banco de dados.');
}

define('CHAVE_SECRETA', $appKey);

function crypto_key(): string {
    return hash('sha256', CHAVE_SECRETA, true);
}

function encrypt_payload(string $plaintext, string &$iv_b64): string {
    $iv = random_bytes(16);
    $iv_b64 = base64_encode($iv);
    $cipher = openssl_encrypt($plaintext, 'AES-256-CBC', crypto_key(), OPENSSL_RAW_DATA, $iv);
    if ($cipher === false) throw new RuntimeException('Falha ao criptografar os dados.');
    return base64_encode($cipher);
}

function decrypt_payload(string $cipher_b64, string $iv_b64): string {
    $iv = base64_decode($iv_b64, true);
    $cipher = base64_decode($cipher_b64, true);
    if ($iv === false || $cipher === false) return '';
    $plain = openssl_decrypt($cipher, 'AES-256-CBC', crypto_key(), OPENSSL_RAW_DATA, $iv);
    return $plain === false ? '' : $plain;
}

function openai_api_key(): string {
    return (string) cfg('OPENAI_API_KEY', 'openai_api_key', '');
}
