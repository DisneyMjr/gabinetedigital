<?php
// saas_config.php - CONFIGURAÇÕES GERAIS, FINANCEIRAS E INTEGRAÇÕES
session_start();
require 'conexao.php';

// 1. SEGURANÇA: Verifica se é Super Admin
if (!isset($_SESSION['saas_admin_id'])) {
    header("Location: saas_login.php");
    exit;
}

$msg = '';
$tipo_msg = '';

// --- LÓGICA: ALTERAR PERFIL DO SUPER ADMIN ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['atualizar_admin'])) {
    $novo_email = trim($_POST['email']);
    $nova_senha = $_POST['senha'];
    
    try {
        if (!empty($nova_senha)) {
            $hash = password_hash($nova_senha, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE super_admins SET email = ?, senha_hash = ? WHERE id = ?");
            $stmt->execute([$novo_email, $hash, $_SESSION['saas_admin_id']]);
        } else {
            $stmt = $pdo->prepare("UPDATE super_admins SET email = ? WHERE id = ?");
            $stmt->execute([$novo_email, $_SESSION['saas_admin_id']]);
        }
        $msg = "Perfil de acesso atualizado com sucesso!";
        $tipo_msg = "success";
    } catch (Exception $e) {
        $msg = "Erro ao atualizar perfil: " . $e->getMessage();
        $tipo_msg = "danger";
    }
}

// --- LÓGICA: ATUALIZAR CONFIGURAÇÕES DO SISTEMA ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['atualizar_sistema'])) {
    $nome_sistema = trim($_POST['nome_sistema']);
    $valor_mensalidade = str_replace(',', '.', $_POST['valor_mensalidade']); // Formata para 99.90
    $mp_token = trim($_POST['mp_access_token']);
    $mp_webhook_secret = trim($_POST['mp_webhook_secret'] ?? '');
    $app_url = rtrim(trim($_POST['app_url'] ?? ''), '/');

    try {
        // Função auxiliar para UPSERT (Atualizar ou Inserir)
        function salvarConfig($pdo, $chave, $valor) {
            $sql = "INSERT INTO system_config (chave, valor) VALUES (?, ?) 
                    ON DUPLICATE KEY UPDATE valor = VALUES(valor)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$chave, $valor]);
        }

        // 1. Salva Nome do Sistema
        salvarConfig($pdo, 'nome_sistema', $nome_sistema);

        // 2. Salva Valor da Mensalidade
        salvarConfig($pdo, 'valor_mensalidade', $valor_mensalidade);

        // 3. Salva Token do Mercado Pago
        salvarConfig($pdo, 'mp_access_token', $mp_token);
        salvarConfig($pdo, 'mp_webhook_secret', $mp_webhook_secret);
        salvarConfig($pdo, 'app_url', $app_url);
        
        $msg = "Configurações do SaaS salvas com sucesso!";
        $tipo_msg = "info";
        
        // Atualiza a página para recarregar os valores nos inputs
        header("Refresh:1");

    } catch (Exception $e) {
        $msg = "Erro ao salvar configurações: " . $e->getMessage();
        $tipo_msg = "danger";
    }
}

// --- BUSCAR DADOS PARA EXIBIR ---
// 1. Dados do Admin
$admin = $pdo->query("SELECT email FROM super_admins WHERE id = " . $_SESSION['saas_admin_id'])->fetch();

// 2. Configurações do Sistema (Traz tudo como um array chave => valor)
$stmtConfig = $pdo->query("SELECT chave, valor FROM system_config");
$configs = $stmtConfig->fetchAll(PDO::FETCH_KEY_PAIR);

// Define valores padrão caso o banco esteja vazio
$config_nome = $configs['nome_sistema'] ?? 'Ouvidoria SaaS';
$config_valor = $configs['valor_mensalidade'] ?? '97.00';
$config_mp_token = $configs['mp_access_token'] ?? '';
$config_mp_webhook_secret = $configs['mp_webhook_secret'] ?? '';
$config_app_url = $configs['app_url'] ?? '';
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Configurações | SaaS Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body { background-color: #f0f2f5; font-family: 'Segoe UI', sans-serif; }
        .sidebar { min-height: 100vh; background: #212529; color: white; width: 250px; position: fixed; }
        .content { margin-left: 250px; padding: 30px; }
        @media (max-width: 768px) {
            .sidebar { width: 100%; position: relative; min-height: auto; }
            .content { margin-left: 0; }
        }
    </style>
</head>
<body>

<div class="sidebar p-3 d-none d-md-block">
    <h4 class="fw-bold mb-4 px-2 text-warning"><i class="bi bi-rocket-takeoff"></i> SaaS HQ</h4>
    <ul class="nav flex-column gap-2">
        <li class="nav-item"><a href="painel.php" class="nav-link text-white opacity-75"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li class="nav-item"><a href="saas_financeiro.php" class="nav-link text-white opacity-75"><i class="bi bi-cash-stack"></i> Financeiro</a></li>
        <li class="nav-item"><a href="saas_config.php" class="nav-link text-white bg-primary rounded fw-bold"><i class="bi bi-gear"></i> Configurações</a></li>
        <li class="nav-item mt-5 border-top pt-3"><a href="saas_logout.php" class="nav-link text-danger"><i class="bi bi-box-arrow-left"></i> Sair</a></li>
    </ul>
</div>

<div class="content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold text-secondary">Configurações Gerais</h2>
    </div>

    <?php if($msg): ?>
        <div class="alert alert-<?php echo $tipo_msg; ?> alert-dismissible fade show" role="alert">
            <?php echo $msg; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-5">
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white py-3">
                    <h5 class="mb-0 fw-bold text-dark"><i class="bi bi-person-lock"></i> Meu Acesso Master</h5>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <input type="hidden" name="atualizar_admin" value="1">
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold small text-secondary">E-MAIL DE LOGIN</label>
                            <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($admin['email']); ?>" required>
                        </div>

                        <div class="mb-4">
                            <label class="form-label fw-bold small text-secondary">NOVA SENHA</label>
                            <input type="password" name="senha" class="form-control" placeholder="Deixe em branco para manter a atual">
                            <div class="form-text">Preencha apenas se quiser trocar sua senha.</div>
                        </div>

                        <div class="d-grid">
                            <button class="btn btn-outline-primary fw-bold">Salvar Meu Perfil</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-7">
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white py-3">
                    <h5 class="mb-0 fw-bold text-dark"><i class="bi bi-sliders"></i> Parâmetros do SaaS</h5>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <input type="hidden" name="atualizar_sistema" value="1">
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold small text-secondary">NOME DO SISTEMA (White Label)</label>
                                <input type="text" name="nome_sistema" class="form-control" value="<?php echo htmlspecialchars($config_nome); ?>" placeholder="Ex: Ouvidoria Pro">
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold small text-success">VALOR MENSALIDADE (R$)</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-success text-white fw-bold">R$</span>
                                    <input type="text" name="valor_mensalidade" class="form-control fw-bold text-success" value="<?php echo htmlspecialchars($config_valor); ?>">
                                </div>
                            </div>
                        </div>

                        <hr class="my-3">

                        <div class="mb-3">
                            <label class="form-label fw-bold small text-secondary">URL PÚBLICA DO SISTEMA</label>
                            <input type="url" name="app_url" class="form-control" value="<?php echo htmlspecialchars($config_app_url); ?>" placeholder="https://seudominio.com.br">
                            <div class="form-text">Usada no retorno da assinatura. Informe sem barra no final.</div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold small text-primary">ACCESS TOKEN (MERCADO PAGO)</label>
                            <input type="password" name="mp_access_token" class="form-control font-monospace" value="<?php echo htmlspecialchars($config_mp_token); ?>" placeholder="APP_USR-xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx">
                            <div class="form-text">Credencial de produção usada pela API de Assinaturas do Mercado Pago.</div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold small text-primary">CHAVE SECRETA DO WEBHOOK</label>
                            <input type="password" name="mp_webhook_secret" class="form-control font-monospace" value="<?php echo htmlspecialchars($config_mp_webhook_secret); ?>" placeholder="Chave exibida em Webhooks no Mercado Pago">
                            <div class="form-text">No Mercado Pago configure o webhook em <strong><?php echo htmlspecialchars(($config_app_url ?: 'https://seudominio.com.br') . '/webhook_mp.php'); ?></strong>.</div>
                        </div>

                        <div class="d-grid mt-4">
                            <button class="btn btn-dark fw-bold">Atualizar Parâmetros</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>