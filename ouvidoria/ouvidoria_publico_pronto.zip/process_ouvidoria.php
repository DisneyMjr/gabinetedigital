<?php
require 'conexao.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit('Método inválido'); }

$tenant_id = (int)($_POST['tenant_id'] ?? 0);
$setor_id = $_POST['setor_id'] ?? null;
$setor_id = ($setor_id === '' || $setor_id === '0') ? null : (int)$setor_id;

$tipo_manifestacao = trim($_POST['tipo_manifestacao'] ?? ($_POST['tipo_assunto'] ?? 'Solicitação'));
$texto_bruto = trim($_POST['relato_bruto'] ?? '');
$slug = $_POST['slug'] ?? '';

if ($tenant_id <= 0 || $texto_bruto === '') { http_response_code(400); exit('Dados obrigatórios ausentes.'); }

$is_anonimo = (int)($_POST['is_anonimo'] ?? 0);
$nome = trim($_POST['nome'] ?? '');
$email = trim($_POST['email'] ?? '');
$telefone = trim($_POST['telefone'] ?? '');
if ($is_anonimo === 1) { $nome = $email = $telefone = ''; }

$protocolo = strtoupper(substr(bin2hex(random_bytes(6)), 0, 12));
$prazo_resposta = (new DateTime('now'))->modify('+20 days')->format('Y-m-d H:i:s');

$iv_b64 = '';
$texto_cipher = encrypt_payload($texto_bruto, $iv_b64);

$resumo_ai = null;
$openAiKey = openai_api_key();
if ($openAiKey) {
    $url = 'https://api.openai.com/v1/chat/completions';
    $prompt_sistema = "Você é um Auditor Jurídico Sênior e Especialista em Ouvidoria e Compliance. Crie um resumo formal, objetivo e técnico do relato, sem gírias e sem reproduzir ofensas. Estruture em: (1) Fatos relatados (2) Possíveis riscos (3) Sugestão de encaminhamento.";
    $payload = [
        'model' => 'gpt-4o-mini',
        'messages' => [
            ['role' => 'system', 'content' => $prompt_sistema],
            ['role' => 'user', 'content' => $texto_bruto]
        ],
        'temperature' => 0.2,
        'max_tokens' => 450
    ];
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $openAiKey
        ],
        CURLOPT_POSTFIELDS => json_encode($payload),
        CURLOPT_TIMEOUT => 20,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    $resp = curl_exec($ch);
    $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($resp && $http >= 200 && $http < 300) {
        $j = json_decode($resp, true);
        $resumo_ai = $j['choices'][0]['message']['content'] ?? null;
    }
}

$sql = "INSERT INTO reports 
(tenant_id, setor_id, protocolo_visualizacao, tipo_assunto, tipo_manifestacao, relato_original, iv, relato_ia, status, resposta_publica, created_at, is_anonimo, prazo_resposta, modulo, nome, email, telefone)
VALUES
(?, ?, ?, ?, ?, ?, ?, ?, 'Recebido', NULL, NOW(), ?, ?, 'OUVIDORIA', ?, ?, ?)";
$stmt = $pdo->prepare($sql);
$stmt->execute([
    $tenant_id, $setor_id, $protocolo, $tipo_manifestacao, $tipo_manifestacao,
    $texto_cipher, $iv_b64, $resumo_ai, $is_anonimo, $prazo_resposta, $nome, $email, $telefone
]);

header("Location: index.php?empresa=" . urlencode($slug) . "&status=sucesso&protocolo=" . urlencode($protocolo));
exit;
?>