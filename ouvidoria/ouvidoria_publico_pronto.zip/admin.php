<?php
// admin.php - PAINEL DE GESTÃO COMPLETO (SaaS)
session_start();
require 'conexao.php';
require 'verificar_assinatura.php'; // Bloqueia se o trial venceu

$tenant_id = $_SESSION['tenant_id'];
$user_nome = $_SESSION['user_nome'];

// --- 1. PROCESSAR ATUALIZAÇÃO DE STATUS/RESPOSTA (OUVIDORIA) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['atualizar_relato'])) {
    $id_relato = (int)$_POST['id_relato'];
    $novo_status = $_POST['status'];
    $resposta = trim($_POST['resposta_publica']);

    // Atualiza o banco
    $stmtUpd = $pdo->prepare("UPDATE reports SET status = ?, resposta_publica = ? WHERE id = ? AND tenant_id = ?");
    $stmtUpd->execute([$novo_status, $resposta, $id_relato, $tenant_id]);
    
    // Recarrega a página para evitar reenvio de formulário
    header("Location: admin.php"); 
    exit;

// --- 1B. PROCESSAR ATUALIZAÇÃO DE STATUS/RESPOSTA (LAI) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['atualizar_lai'])) {
    $id_lai = (int)$_POST['id_lai'];
    $novo_status = $_POST['status_lai'];
    $resposta = trim($_POST['resposta_publica_lai']);
    $prorrogado = isset($_POST['prorrogado']) ? 1 : 0;
    $just = trim($_POST['justificativa_prorrogacao']);

    $stmtUpd = $pdo->prepare("UPDATE lai_pedidos SET status = ?, resposta_publica = ?, prorrogado = ?, justificativa_prorrogacao = ?, updated_at = NOW() WHERE id = ? AND tenant_id = ?");
    $stmtUpd->execute([$novo_status, $resposta, $prorrogado, ($just?:null), $id_lai, $tenant_id]);

    header("Location: admin.php");
    exit;
}

}

// --- 2. DADOS DA EMPRESA (Para o cabeçalho e link) ---
$stmtEmpresa = $pdo->prepare("SELECT nome_empresa, slug, data_expiracao FROM tenants WHERE id = ?");
$stmtEmpresa->execute([$tenant_id]);
$dadosEmpresa = $stmtEmpresa->fetch();

$nome_empresa = $dadosEmpresa['nome_empresa'];
$slug_empresa = $dadosEmpresa['slug'];

// Cálculo de dias restantes
$data_validade = new DateTime($dadosEmpresa['data_expiracao']);
$hoje = new DateTime();
$diferenca = $hoje->diff($data_validade);
$dias_restantes = (int)$diferenca->format("%r%a");

// Geração Automática do Link Amigável
$protocolo = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? "https" : "http";
$servidor = $_SERVER['HTTP_HOST'];
$caminho = "/ouvidoria"; // Ajuste se necessário
$meu_link = "{$protocolo}://{$servidor}{$caminho}/index.php?empresa=" . $slug_empresa;

// --- 3. BUSCAR RELATOS (COM JOIN PARA PEGAR O NOME DO SETOR) ---
// Usamos LEFT JOIN para trazer o nome do setor. Se for NULL, traz vazio.
$sqlRelatos = "SELECT r.*, s.nome as nome_setor 
               FROM reports r 
               LEFT JOIN sectors s ON r.sector_id = s.id 
               WHERE r.tenant_id = ? 
               ORDER BY r.created_at DESC";
$stmtRelatos = $pdo->prepare($sqlRelatos);
$stmtRelatos->execute([$tenant_id]);
$relatorios = $stmtRelatos->fetchAll();

// Função de Cores
function getCorUrgencia($nivel) {
    if($nivel >= 5) return 'danger';   // Vermelho Escuro
    if($nivel == 4) return 'warning';  // Laranja/Amarelo
    return 'info';                     // Azul
}

function getCorStatus($status) {
    if($status == 'novo') return 'primary';
    if($status == 'em_analise') return 'warning';
    return 'success';
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Painel Gestor | <?php echo htmlspecialchars($nome_empresa); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body { background-color: #f4f6f9; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .card-dash { border: none; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); transition: transform 0.2s; }
        .card-dash:hover { transform: translateY(-2px); box-shadow: 0 8px 15px rgba(0,0,0,0.1); }
        .blur-text { filter: blur(6px); user-select: none; cursor: pointer; background: #f8f9fa; color: transparent; text-shadow: 0 0 8px rgba(0,0,0,0.2); transition: 0.4s; }
        .reveal { filter: blur(0); cursor: text; background: #fff; color: #333; text-shadow: none; }
        .bg-gradient-dark { background: linear-gradient(135deg, #212529 0%, #343a40 100%); }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-gradient-dark px-4 shadow-sm sticky-top">
        <a class="navbar-brand fw-bold" href="#"><i class="bi bi-shield-check"></i> <?php echo htmlspecialchars($nome_empresa); ?></a>
        
        <div class="d-flex ms-auto align-items-center text-white gap-3">
            <a href="admin_setores.php" class="btn btn-outline-light btn-sm">
                <i class="bi bi-building-gear"></i> Gerenciar Setores
            </a>

            <div class="d-none d-md-block border-end pe-3">
                <?php if($dias_restantes > 5): ?>
                    <span class="badge bg-success rounded-pill"><i class="bi bi-clock"></i> <?php echo $dias_restantes; ?> dias</span>
                <?php else: ?>
                    <span class="badge bg-danger rounded-pill"><i class="bi bi-exclamation-circle"></i> Expira em <?php echo $dias_restantes; ?> dias</span>
                <?php endif; ?>
            </div>

            <div class="lh-1 text-end">
                <span class="d-block fw-bold small"><?php echo htmlspecialchars($user_nome); ?></span>
                <span class="d-block x-small opacity-75" style="font-size: 0.75rem;"><?php echo htmlspecialchars($nome_empresa); ?></span>
            </div>
            <a href="logout.php" class="btn btn-sm btn-danger"><i class="bi bi-box-arrow-right"></i></a>
        </div>
    </nav>

    <div class="container mt-4 pb-5">

        <div class="row mb-4">
            <div class="col-12">
                <div class="card card-dash bg-white p-4">
                    <div class="row align-items-center">
                        <div class="col-md-7">
                            <h5 class="fw-bold text-primary mb-1">📢 Seu Canal de Denúncias</h5>
                            <p class="text-muted mb-0 small">Copie o link abaixo e divulgue na intranet ou grupos da empresa.</p>
                        </div>
                        <div class="col-md-5">
                            <div class="input-group">
                                <input type="text" class="form-control bg-light text-primary fw-bold" id="meuLink" value="<?php echo $meu_link; ?>" readonly>
                                <button class="btn btn-primary" onclick="copiarLink()"><i class="bi bi-clipboard"></i> Copiar</button>
                                <a href="<?php echo $meu_link; ?>" target="_blank" class="btn btn-outline-secondary"><i class="bi bi-box-arrow-up-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="d-flex justify-content-between align-items-end mb-3">
            <h5 class="text-secondary fw-bold m-0"><i class="bi bi-inbox"></i> Relatos Recebidos (<?php echo count($relatorios); ?>)</h5>
        </div>

        <?php if(count($relatorios) == 0): ?>
            <div class="text-center py-5 opacity-50">
                <i class="bi bi-folder2-open display-1"></i>
                <h4 class="mt-3">Nenhum relato recebido ainda.</h4>
            </div>
        <?php endif; ?>

        <div class="row">
            <?php foreach($relatorios as $relato): 
                $texto_original = openssl_decrypt($relato['texto_original_criptografado'], "AES-128-CTR", CHAVE_SECRETA, 0, IV_SECRETO);
            ?>
            <div class="col-12 mb-4">
                <div class="card card-dash h-100">
                    <div class="card-header bg-white border-bottom-0 pt-3 px-4 pb-0">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <span class="badge bg-<?php echo getCorStatus($relato['status']); ?> text-uppercase mb-2">
                                    <?php echo str_replace('_', ' ', $relato['status']); ?>
                                </span>
                                
                                <span class="badge border text-dark ms-1">
                                    <i class="bi bi-tag-fill text-muted"></i> <?php echo htmlspecialchars($relato['categoria_ia']); ?>
                                </span>

                                <?php if($relato['nome_setor']): ?>
                                    <span class="badge bg-light text-dark border ms-1">
                                        <i class="bi bi-building"></i> <?php echo htmlspecialchars($relato['nome_setor']); ?>
                                    </span>
                                <?php endif; ?>

                                <h5 class="card-title mt-2 mb-0 text-dark fw-bold">
                                    #<?php echo $relato['protocolo_visualizacao']; ?>
                                </h5>
                                <small class="text-muted" style="font-size: 0.8rem;">
                                    Recebido em <?php echo date('d/m/Y \à\s H:i', strtotime($relato['created_at'])); ?>
                                </small>
                            </div>

                            <div class="text-end">
                                <span class="badge bg-<?php echo getCorUrgencia($relato['urgencia_ia']); ?> p-2">
                                    Risco Jurídico: <?php echo $relato['urgencia_ia']; ?>/5
                                </span>
                            </div>
                        </div>
                    </div>

                    <div class="card-body px-4">
                        <hr class="text-muted opacity-25">
                        <div class="row g-4">
                            <div class="col-md-6 border-end">
                                <h6 class="text-uppercase text-primary small fw-bold mb-3">
                                    <i class="bi bi-robot"></i> Análise Técnica (IA)
                                </h6>
                                <div class="mb-3">
                                    <label class="small text-muted fw-bold">RESUMO TÉCNICO:</label>
                                    <p class="card-text text-dark"><?php echo htmlspecialchars($relato['resumo_ia']); ?></p>
                                </div>
                                <div class="bg-light p-3 rounded border-start border-4 border-info">
                                    <strong class="d-block text-dark small mb-1"><i class="bi bi-lightbulb"></i> Recomendação:</strong>
                                    <span class="fst-italic text-secondary small">
                                        "<?php echo htmlspecialchars($relato['sugestao_acao']); ?>"
                                    </span>
                                </div>
                            </div>

                            <div class="col-md-6 ps-md-4">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <h6 class="text-uppercase text-secondary small fw-bold mb-0">
                                        <i class="bi bi-file-earmark-lock"></i> Relato Original
                                    </h6>
                                    <button class="btn btn-sm btn-outline-secondary py-0" style="font-size: 0.75rem;" onclick="toggleText(<?php echo $relato['id']; ?>)">
                                        <i class="bi bi-eye"></i> Revelar
                                    </button>
                                </div>
                                
                                <div class="p-3 border rounded bg-white position-relative">
                                    <div id="raw-text-<?php echo $relato['id']; ?>" class="blur-text p-1">
                                        <?php echo nl2br(htmlspecialchars($texto_original)); ?>
                                    </div>
                                    <div class="text-center mt-2">
                                        <small class="text-muted fst-italic" style="font-size: 0.7rem;">Dados sensíveis criptografados.</small>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="mt-4 bg-light p-3 rounded border">
                            <h6 class="fw-bold small text-secondary mb-3"><i class="bi bi-chat-left-text"></i> GESTÃO DO CASO</h6>
                            
                            <form method="POST">
                                <input type="hidden" name="atualizar_relato" value="1">
                                <input type="hidden" name="id_relato" value="<?php echo $relato['id']; ?>">
                                
                                <div class="row g-2">
                                    <div class="col-md-3">
                                        <label class="form-label small fw-bold">Status Atual</label>
                                        <select name="status" class="form-select form-select-sm">
                                            <option value="novo" <?php echo $relato['status']=='novo'?'selected':''; ?>>🔴 Novo</option>
                                            <option value="em_analise" <?php echo $relato['status']=='em_analise'?'selected':''; ?>>🟡 Em Análise</option>
                                            <option value="concluido" <?php echo $relato['status']=='concluido'?'selected':''; ?>>🟢 Concluído</option>
                                        </select>
                                    </div>
                                    <div class="col-md-7">
                                        <label class="form-label small fw-bold">Resposta para o Colaborador (Pública)</label>
                                        <textarea name="resposta_publica" class="form-control form-control-sm" rows="1" placeholder="Ex: Recebemos seu relato e iniciamos a apuração..."><?php echo htmlspecialchars($relato['resposta_publica'] ?? ''); ?></textarea>
                                    </div>
                                    <div class="col-md-2 d-flex align-items-end">
                                        <button type="submit" class="btn btn-sm btn-success w-100 fw-bold">
                                            <i class="bi bi-save"></i> Atualizar
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function toggleText(id) {
            const el = document.getElementById('raw-text-' + id);
            if (el.classList.contains('blur-text')) {
                if(confirm('Atenção: Você está prestes a revelar dados sensíveis. Continuar?')) {
                    el.classList.remove('blur-text');
                    el.classList.add('reveal');
                }
            } else {
                el.classList.add('blur-text');
                el.classList.remove('reveal');
            }
        }

        function copiarLink() {
            var copyText = document.getElementById("meuLink");
            copyText.select();
            copyText.setSelectionRange(0, 99999); 
            navigator.clipboard.writeText(copyText.value);
            alert("Link copiado para a área de transferência!");
        }
    </script>
</body>
</html>