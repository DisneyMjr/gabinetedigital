<?php
// acompanhar.php - ÁREA PÚBLICA DE CONSULTA (CORRIGIDO)
require 'conexao.php';

$relato = null;
$erro = '';

if (isset($_GET['protocolo'])) {
    $protocolo = strtoupper(trim($_GET['protocolo']));
    
    // CORREÇÃO: Especificamos 'reports.created_at' para não confundir com a data da empresa
    $sql = "SELECT reports.status, 
                   reports.resposta_publica, 
                   reports.created_at, 
                   tenants.nome_empresa 
            FROM reports 
            JOIN tenants ON reports.tenant_id = tenants.id 
            WHERE reports.protocolo_visualizacao = ?";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$protocolo]);
    $relato = $stmt->fetch();

    if (!$relato) {
        // Tenta LAI
        $sql2 = "SELECT status, resposta_publica, created_at, prazo_resposta, 'LAI' as modulo, tenants.nome_empresa
                 FROM lai_pedidos 
                 JOIN tenants ON lai_pedidos.tenant_id = tenants.id
                 WHERE lai_pedidos.protocolo = ?";
        $stmt2 = $pdo->prepare($sql2);
        $stmt2->execute([$protocolo]);
        $relato = $stmt2->fetch();
    }

    if (!$relato) {
        $erro = "Protocolo não encontrado. Verifique o código digitado.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Acompanhar Protocolo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; display: flex; align-items: center; justify-content: center; min-height: 100vh; }
        .card-busca { max-width: 500px; width: 100%; border: none; box-shadow: 0 5px 20px rgba(0,0,0,0.05); }
    </style>
</head>
<body>
    <div class="card card-busca p-4 bg-white">
        <h4 class="text-center mb-4 fw-bold text-primary">🔍 Consultar Relato</h4>

        <form class="mb-4 d-flex gap-2">
            <input type="text" name="protocolo" class="form-control form-control-lg text-uppercase fw-bold" placeholder="DIGITE O PROTOCOLO" value="<?php echo htmlspecialchars($_GET['protocolo'] ?? ''); ?>" required>
            <button class="btn btn-primary">Buscar</button>
        </form>

        <?php if($erro): ?>
            <div class="alert alert-danger text-center"><?php echo $erro; ?></div>
        <?php endif; ?>

        <?php if($relato): ?>
            <div class="border rounded p-3 bg-light">
                <div class="d-flex justify-content-between mb-3">
                    <small class="text-muted fw-bold"><?php echo htmlspecialchars($relato['nome_empresa']); ?></small>
                    <small class="text-muted"><?php echo date('d/m/Y', strtotime($relato['created_at'])); ?></small>
                </div>

                <h5 class="mb-3">Status: 
                    <?php if($relato['status'] == 'novo'): ?>
                        <span class="badge bg-primary">Recebido</span>
                    <?php elseif($relato['status'] == 'em_analise'): ?>
                        <span class="badge bg-warning text-dark">Em Análise</span>
                    <?php else: ?>
                        <span class="badge bg-success">Concluído</span>
                    <?php endif; ?>
                </h5>

                <hr>

                <h6 class="fw-bold text-secondary">Resposta da Empresa:</h6>
                <?php if($relato['resposta_publica']): ?>
                    <p class="mb-0 text-dark bg-white p-2 rounded border"><?php echo nl2br(htmlspecialchars($relato['resposta_publica'])); ?></p>
                <?php else: ?>
                    <p class="text-muted fst-italic">Ainda não há uma resposta pública para este relato. Por favor, aguarde a análise.</p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        
        <div class="text-center mt-3">
            <a href="javascript:history.back()" class="text-decoration-none small">Voltar</a>
        </div>
    </div>
</body>
</html>