<?php
// conexao.php
$host = 'localhost';
$db   = 'ouvidoria_saas';
$user = 'root';
$pass = ''; // Se tiver senha no seu MySQL, coloque aqui
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}

// Chave para criptografia (Em produção, coloque no .env)
define('CHAVE_SECRETA', 'SuaChaveSuperSecreta32Caracteres!'); 

// =========================
// SEGURANÇA / CRIPTOGRAFIA
// =========================
// Em produção: mova CHAVE_SECRETA e OPENAI_API_KEY para variáveis de ambiente
// Ex.: export OPENAI_API_KEY="sk-..."
// A chave é derivada com SHA-256 para sempre ter 32 bytes (AES-256).

function crypto_key(): string {
    return hash('sha256', CHAVE_SECRETA, true); // 32 bytes
}

function encrypt_payload(string $plaintext, string &$iv_b64): string {
    $iv = random_bytes(16);
    $iv_b64 = base64_encode($iv);
    $cipher = openssl_encrypt($plaintext, 'AES-256-CBC', crypto_key(), OPENSSL_RAW_DATA, $iv);
    return base64_encode($cipher);
}

function decrypt_payload(string $cipher_b64, string $iv_b64): string {
    $iv = base64_decode($iv_b64);
    $cipher = base64_decode($cipher_b64);
    $plain = openssl_decrypt($cipher, 'AES-256-CBC', crypto_key(), OPENSSL_RAW_DATA, $iv);
    return $plain === false ? '' : $plain;
}

function openai_api_key(): string {
    $k = getenv('OPENAI_API_KEY');
    return $k ? $k : '';
}

?>